module.exports = {
    llave: "miclaveultrasecreta123*"
}